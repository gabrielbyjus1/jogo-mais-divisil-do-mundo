var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var p1 = createSprite(190,120,250,3);
var p2 = createSprite(190, 260,250,3);
var p3 = createSprite(67,145,3,50);
var p4 = createSprite(67,235,3,50);
var p5 = createSprite(313,145,3,50);
var p6 = createSprite(313,235,3,50);
var p7= createSprite(41,170,50,3);
var p8 = createSprite(41,210,50,3);
var p9 = createSprite(337,170,50,3);
var p10 = createSprite(18,190,3,40);
var p11 = createSprite(361,190,3,40);
var p12 = createSprite(337,210,50,3);


var s = createSprite(40,190,13,13);
s.shapeColor = 'blue';

var i1 = createSprite(100,130,10,10);
i1.shapeColor = 'red';

var i2 = createSprite(215,130,10,10);
i2.shapeColor = 'red';

var i3 = createSprite(165,250,10,10);
i3.shapeColor = 'red';


var i4 = createSprite(270,250,10,10);
i4.shapeColor = 'red';

i1.velocityY = 8;
i2.velocityY = 8;
i3.velocityY =- 8;
i4.velocityY = -8;

var perdeu = 0;



function draw() {
background("white");

playSound("assets/category_animals/dinosaur.mp3", true);


textSize(18);
text("perdeu"+perdeu, 270, 60);




if (keyDown("right")) {
s.x = s.x +10;  
}

if (keyDown("LEFT")) {
 s.x = s.x -10; 
}


i1.bounceOff(p1);
i1.bounceOff(p2);

i2.bounceOff(p1);
i2.bounceOff(p2);

i3.bounceOff(p1);
i3.bounceOff(p2);

i4.bounceOff(p1);
i4.bounceOff(p2);

drawSprites();


if (s.isTouching(p11)||
s.isTouching(p10)||
s.isTouching(i1)||
s.isTouching(i2)||
s.isTouching(i3)||
s.isTouching(i4)){ 
                                                                

s.x = 40;
s.y = 190;

perdeu = perdeu +1;
}












    
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
